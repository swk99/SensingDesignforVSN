README
____________________________________________
This folder is custom environment for Data Update in Vehicular Network considering Age of Information.

State : 
Action : 
Reward : 