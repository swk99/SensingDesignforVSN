#gym-hw/setup.py
#custom gym 공간 등록
from setuptools import setup
setup(name = 'gym_hw',
      version = '0.0.2',
      install_requires = ['gym'])