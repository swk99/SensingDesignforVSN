#gym-hw/gym_hw/__init__.py
from gym.envs.registration import register


register(
    id = 'vsn-v0',
    entry_point = 'gym_hw.envs:VsnAgentV0'
)

