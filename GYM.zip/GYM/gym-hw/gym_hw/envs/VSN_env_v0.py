#v0 (221024) : simple crossroad example (4 sensors)
import gym
from gym import error, spaces, utils
from gym.utils import seeding
import copy
import random
import time
import logging
import math
import sys
import os
import numpy as np
import pandas as pd
#import pygame
#from pygame import gfxdraw
from ipdb import set_trace as debug

NUM_ACTION_FOR_AGENT = 5  # no sensing(0), select s1(1), s2(2), s3(3), s4(4)

# 1 episode = 30 ts / 30 ts 마다 새로운 날짜의 data
df_data_tem = pd.read_csv('./data/env_data_tem.csv')


class VsnAgentV0(gym.Env, list):
    # initialization
    def __init__(self):
        print("VSN simple crossroad environment")
        
        self.df_num_veh = pd.read_csv('./data/crossroad_avg_veh_num.csv')
        self.EPISODE_LENGTH = 30
        
        # var_input으로 나중에 받을 파라미터들
        self.TIME_SLOT = 120 # sec
        self.WINDOW = 5
        self.TIME_DECISION = 1 # sec
        
        self.NUM_SENSOR = 4
        self.NUM_EDGE = 4
        self.POS_SENSOR = np.array([[-100,0],[0,200],[300,0],[0,-400]])
        self.POS_EDGE = np.array([[-250,250],[250,250],[250,-250],[-250,-250]])
        self.AREA_EDGE = np.array([[-500,500],[-500,500]])

        self.DATA_SIZE_MB = 1 # MB
        
        self.TX_POWER_DBM = 25
        self.NOISE_POWER_DBM = -80
        self.BANDWIDTH = 5 * (10 ** 6)
        self.USER_DENSITY = 4*10**(-6) # node/m^2 (interfering user density)
        
        self.DATA_RATE_CONST = 2 * (10 ** 6) # 2Mbps ==> TX time = 0.5
        self.ERR_CONST = 0.3
        self.WEIGHT = 0.05
        
        """
        # Real Data set
        self.HUM_CORR = 0.0005483
        """
        # Temporary value
        self.HUM_CORR = 0.0005483 ## AoI threshold = 245.416
        
        self.DATA_SIZE = self.DATA_SIZE_MB * (8 * 10**6)
        self.TX_POWER = 10 ** (self.TX_POWER_DBM/10)
        self.NOISE_POWER = 10 ** (self.NOISE_POWER_DBM/10)    
        
        # Observation: Number of vehicles, current error, and update success ratio during past 5 steps at each sensing region
        self.observation_space = spaces.Box(low=0, high=1, shape=(3*self.NUM_SENSOR, ))
        self.action_space = spaces.Box(low=0, high=1, shape=(self.NUM_SENSOR, ))
        
        
    
    """
    # training 돌릴 때 건드릴 parameters        
    def var_input(self,spec_dict):
            self.NUM_SENSOR = spec_dict['num_sensor']
            self.DATA_SIZE_MB = spec_dict['data_size_MB']
            self.RATE_CONST = spec_dict['datarate_constraint']
            self.ERR_CONST = spec_dict['error_constraint']
            self.USER_DENSITY = spec_dict['user_density']
            
            self.observation_space = []
            self.action_space = []
    """
            
            
            
    def seed(self,seed_num):
        np.random.seed(seed_num)
               
            
            
            
    # 각 episode가 시작될 때마다 리셋시킬 파라미터들
    # Vehicle mobility, AoI, error
    def reset(self):
        self.AoI = np.zeros(self.NUM_SENSOR)
        self.AoI_peak = np.zeros(self.NUM_SENSOR)
        self.est_err = np.zeros(self.NUM_SENSOR)
        self.eta = np.zeros(self.NUM_SENSOR)
        self.cur_sense_idx = 0
        self.ts = 0
        self.done = False
        self.action = np.zeros(self.NUM_SENSOR)
        

        """
        <Simple Crossroad example ONLY>
        - 1시간동안 (즉, 1 episode = 30 time steps) 2분마다 측정된 
        각 sensing region을 지나간 차량의 평균 개수/s 는 고정시켰음
        - 위의 개수/s를 확률이라고 치자!
        - 총 30개의 time step에 대해, 각 확률에 따라 실제로 차량이
        각 sensing region에 위치해 있는지 없는지를 realization 해야 함
        """
        self.real_veh = self.realization(self.df_num_veh)
        
        self.avg_veh = np.zeros(self.NUM_SENSOR)
        self.avg_tx = np.zeros(self.NUM_SENSOR)
        
        self.STACK_VEH = np.zeros(self.NUM_SENSOR)
        self.STACK_TX_TIME = np.zeros(self.NUM_SENSOR)
        
        self.AoI_norm = self.AoI / self.TIME_SLOT

        self.state = []
        self.state.append(np.concatenate([self.avg_veh, self.avg_tx, self.AoI_norm]))
        
        

        return self.state
    
    
    
    # fn step: simulation through each 'frame'
    # at the end of the frame, AoI is updated
    def step(self, act_input):
        self.action = act_input
        
        # =========================Initialization=========================
        self.reward = 0
        
        # =========================Mobility of vehicles=========================
        self.real_veh_step = self.real_veh.iloc[self.ts] #[V1,V2,V3,V4]
        self.real_veh_step = np.array(self.real_veh_step)
        
        
        # =========================Calculate STP=========================
        # Main link power
        self.main_DIST = self.distance(self.POS_SENSOR, self.POS_EDGE)
        self.main_PL = self.main_DIST ** (-4)
        self.main_channel = np.random.exponential(scale=1.0, size=(1,self.NUM_SENSOR))
        
        self.main_power = self.TX_POWER * self.main_channel * self.main_PL
        
        
        # Interference power
        # Interfering users are distributed as PPP with user density (same as BS density)
        # Each sensor has different interfering user set (PPP X num_sensor)
        
        self.interf_power = np.zeros((1,self.NUM_SENSOR))
        
        for i in range(self.NUM_SENSOR):
            self.interf_x, self.interf_y = self.ppp(self.AREA_EDGE, self.USER_DENSITY)
            self.NUM_INTERF = len(self.interf_y)
            
            self.POS_INTERF = np.zeros((self.NUM_INTERF,2))
            for j in range(self.NUM_INTERF):
                self.POS_INTERF[j] = [self.interf_x[j], self.interf_y[j]]
            
            self.interf_power_tmp = self.interference(self.NUM_INTERF, self.NUM_EDGE, self.POS_INTERF, self.POS_EDGE)
            self.interf_power_tmp_copy = copy.copy(self.interf_power_tmp)
            
            self.interf_power[i] = self.interf_power_tmp_copy[i]
            
            del self.interf_x, self.interf_y, self.NUM_INTERF, self.POS_INTERF, self.interf_power_tmp
        
        """
        self.interf_x, self.interf_y = self.ppp(self.AREA_EDGE, self.USER_DENSITY)
        self.NUM_INTERF = len(self.interf_y)
        
        self.POS_INTERF = np.zeros((self.NUM_INTERF,2))
        for j in range(self.NUM_INTERF):
            self.POS_INTERF[j] = [self.interf_x[j], self.interf_y[j]]
        
        self.interf_power = self.interference(self.NUM_INTERF, self.NUM_EDGE, self.POS_INTERF, self.POS_EDGE)
        """
        
        # Calculate SINR
        self.SINR = np.round(self.main_power / (self.interf_power + self.NOISE_POWER), 3)
        
        
        # Calculate data rate
        self.DATA_RATE = self.BANDWIDTH * np.log(1+self.SINR)
        self.DATA_RATE += 10**(-6)
        
        
        # Successful transmission array (e.g., [1,1,0,0])
        self.DATA_RATE_compare = self.DATA_RATE > self.DATA_RATE_CONST
        self.STP = self.DATA_RATE_compare*1
        
        self.TX_TIME = np.round(self.DATA_SIZE * self.STP / self.DATA_RATE_CONST,3)
        
        self.TX_ENERGY = self.TX_TIME * self.TX_POWER;
        
        

        # =========================Sensing indicator based on 'action', 'real_vehicle'=========================
        self.sensing = np.multiply(self.action, self.real_veh_step)
        
    

        # =========================Update AoI=========================
        # Previous AoI
        self.AoI_prev = copy.copy(self.AoI)
        
        # Update AoI & Peak AoI
        for i in range(self.NUM_SENSOR):
            if self.sensing[i] == 1: # If sensing region is selected and vehicle is in it,
                if self.STP[0,i] == 1: # successful TX
                    self.AoI[i] = self.TIME_SLOT - self.TIME_DECISION
                    self.AoI_tmp = self.AoI_prev[i] + self.TIME_DECISION + self.TX_TIME[0,i]
                    self.AoI_peak[i] = max(self.AoI[i], self.AoI_tmp)
                else:
                    self.AoI[i] += self.TIME_SLOT
                    self.AoI_peak[i] = self.AoI[i]
            else:
                self.AoI[i] += self.TIME_SLOT
                self.AoI_peak[i] = self.AoI[i]
                
        
        # AoI threshold obtained from error constraint
        self.AoI_TH = np.log(1-self.ERR_CONST) / (-2*self.HUM_CORR)
        
        # Calculate violation time (eta)
        for i in range(self.NUM_SENSOR):
            if self.AoI_prev[i] < self.AoI_TH:
                if self.AoI_peak[i] > self.AoI_TH:
                    self.eta[i] = self.AoI_peak[i] - self.AoI_TH
                else:
                    self.eta[i] = 0
            else:
                self.eta[i] = self.AoI_peak[i] - self.AoI_prev[i]
    

        # =========================Calculate reward=========================
        self.num_tx = np.sum(self.STP)
        self.ener_total = np.sum(self.TX_ENERGY * self.sensing)
        self.reward += np.sum(self.TIME_SLOT - self.eta) / self.NUM_SENSOR - self.WEIGHT * self.ener_total
        
        
        
        # =========================Update window average for vehicle & STP=========================
        if self.ts == 0:
            self.STACK_VEH = np.array([self.real_veh_step])
            self.STACK_TX_TIME = np.array([self.TX_TIME])
            self.done = False
            
        elif self.ts < self.WINDOW:
            self.STACK_VEH = np.append(self.STACK_VEH, [self.real_veh_step], axis = 0)
            self.STACK_TX_TIME = np.append(self.STACK_TX_TIME, [self.TX_TIME], axis = 0)
            self.done = False
        
        elif self.ts < self.EPISODE_LENGTH:
            self.STACK_VEH = np.delete(self.STACK_VEH, 0, 0)
            self.STACK_VEH = np.append(self.STACK_VEH, [self.real_veh_step], axis = 0)
            
            self.STACK_TX_TIME = np.delete(self.STACK_TX_TIME, 0, 0)
            self.STACK_TX_TIME = np.append(self.STACK_TX_TIME, [self.TX_TIME], axis = 0)
            
            self.done = False
            
        else:
            self.done = True
        
        self.SIZE_WINDOW = len(self.STACK_VEH)
        self.SUM_VEH = np.sum(self.STACK_VEH, axis=0)
        self.SUM_TX_TIME = np.sum(self.STACK_TX_TIME, axis=0)
        
        self.avg_veh = self.SUM_VEH / self.SIZE_WINDOW
        self.avg_tx = self.SUM_TX_TIME / self.SIZE_WINDOW
        
        
    
        # =========================Update step indicator ts=========================
        self.ts += 1    
        
        
        # =========================Return=========================
        self.AoI_norm = self.AoI / self.TIME_SLOT
        
        self.state = []
        self.state.append(np.concatenate([self.avg_veh, self.avg_tx[0], self.AoI_norm]))
        
        return self.state, self.reward, self.done, {'eta': self.eta, 'tx_count': self.num_tx}
    
    # ========================================================================= #
    #                             Defined FUNCTIONS                             #
    # ========================================================================= #
            
    def realization(self, df_num_veh):
        # 확률로 봄 --> 0에서 1사이 값으로 clip 하기
        self.df_num_veh_clip = self.df_num_veh.clip(0,1)
        self.df_num_veh_100 = self.df_num_veh_clip.multiply(100)

        # 0에서 100사이의 random integer 발생 
        self.df_rand = pd.DataFrame(np.random.randint(0,100,size=(30,4)), columns=list('1234'))

        self.df_compare = self.df_num_veh_100 > self.df_rand
        self.num_veh = self.df_compare*1

        return self.num_veh
        
        
    def ppp(self, AREA_EDGE, USER_DENSITY):
        self.xMin = self.AREA_EDGE[0][0]
        self.xMax = self.AREA_EDGE[0][1]
        self.yMin = self.AREA_EDGE[1][0]
        self.yMax = self.AREA_EDGE[1][1]
        
        self.xDelta = self.xMax - self.xMin
        self.yDelta = self.yMax - self.yMin
        
        self.areaTotal = self.xDelta * self.yDelta
        
        self.node_num = np.random.poisson( self.USER_DENSITY * self.areaTotal )
        self.node_x = self.xDelta * np.random.rand(self.node_num) + self.xMin
        self.node_y = self.yDelta * np.random.rand(self.node_num) + self.yMin
        
        return self.node_x, self.node_y

    
    def distance(self,x,y):
        DIST = np.sqrt(np.sum((x-y)**2, axis=1))
        return DIST
 

    def interference(self, NUM_INTERF, NUM_EDGE, POS_INTERF, POS_EDGE):
        self.interf_power = np.zeros(self.NUM_EDGE)
        for count in range(self.NUM_EDGE):
            self.dist_to_edge = self.distance(self.POS_INTERF, self.POS_EDGE[count])
            self.interf_PL = self.dist_to_edge ** (-4)
            self.interf_channel = np.random.exponential(scale=1.0, size=(1,self.NUM_INTERF))
            self.interf_links = self.TX_POWER * self.interf_channel * self.interf_PL
            self.interf_link = sum(sum(self.interf_links))
            self.interf_power[count] = self.interf_link
        return self.interf_power
    
    
            
